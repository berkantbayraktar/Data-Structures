#ifndef _author_h__
#define _author_h__

#include "book.hpp"
#include <cstring>

class AuthorComparator
{
  public:
    bool operator( ) (const Book::SecondaryKey & key1, 
                      const Book::SecondaryKey & key2) const
    {
      //if key1 is less than key2 wrt specifications
      //return true
      //otherwise
      //return false
    	std::string author1 = key1.getAuthor();
    	std::string author2 = key2.getAuthor();
      std::string title1 = key1.getTitle();
      std::string title2 = key2.getTitle();

      for(int i=0;author1[i]!=0;i++){
        if(author1[i]<=122 && author1[i]>=97)
            author1[i]-=32;
      }

      for(int i=0;author2[i]!=0;i++){
        if(author2[i]<=122 && author2[i]>=97)
            author2[i]-=32;
      }

      for(int i=0;title1[i]!=0;i++){
        if(title1[i]<=122 && title1[i]>=97)
            title1[i]-=32;
      }

      for(int i=0;title2[i]!=0;i++){
        if(title2[i]<=122 && title2[i]>=97)
            title2[i]-=32;
      }

      if(author1 < author2)
        return true;

      else if(author1 == author2)
      {
        if(title1 < title2)
          return true;
        else
          return false;
      }
      else
        return false;


    }

};

#endif
