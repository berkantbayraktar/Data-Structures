#include "Article.h"

Article::Article( int table_size,int h1_param, int h2_param )
{    
    this->n = 0;
    this->table_size = table_size;
    this->h1_param = h1_param;
    this->h2_param = h2_param;
    
    table = new  std::pair<std::string,int> [table_size];
    for(int i = 0 ; i < table_size ; i++)
    {
        std::pair<std::string, int> newPair;
        newPair = std::make_pair(EMPTY_KEY,EMPTY_INDEX);
        table[i] = newPair;
    }
}

Article::~Article()
{
    delete  [] table;
}

int Article::get( std::string key, int nth, std::vector<int> &path ) const
{
    int prob = 0;
    int counter = 0;

    while(true)
    {
        int index = hash(key,prob);
        if(table[index].first!=key)
         {   
            if(prob == table_size)
                return -1;

            if(table[index].second == EMPTY_INDEX)
            {
                path.push_back(index);
                return -1;
            }

            if(prob > 0)    
                path.push_back(index); 

            prob++;               
        }

        else
        {   
            counter++;

            if(prob>0)
            path.push_back(index);

            if(counter == nth)
                return table[index].second;
            else
                prob++;
        }
    }
}

int Article::insert( std::string key, int original_index )
{   
    if(MAX_LOAD_FACTOR < getLoadFactor())
        expand_table();
        
    int myProb = 0;
    int index = hash_function(key,myProb);
    std::pair<std::string, int> newPair;
    newPair = std::make_pair(key,original_index);

    while(true)
    {
    	int hashVal = hash(key,myProb);

    	if(table[hashVal].first ==key)
    	{
    		if(table[hashVal].second > original_index)
    			swap(table[hashVal],newPair);

    		myProb++;
    	}

    	else if(table[hashVal].first!=EMPTY_KEY && table[hashVal].second != EMPTY_INDEX)
    		myProb++;
    		
    	else
    		{
    		    table[index] = newPair;
                n++;
                return myProb ;
    		}
    }
}


int Article::remove( std::string key, int nth )
{
	int prob = 0;
    int counter = 0;

    while(true)
    {
        int index = hash(key,prob);

        if(table[index].first!=key)
            {
                prob++;
                if(prob == table_size)
                    return -1;
            }               

        else
        {   
            counter++;

            if(counter == nth)
                {
                    std::pair<std::string, int> newPair;
                    newPair = std::make_pair(EMPTY_KEY,MARKED_INDEX);
                    table[index] = newPair;
                    n--;
                    return prob;
                }
            else
                prob++;
        }
    }
}

double Article::getLoadFactor() const
{
    return double(n) / double(table_size);
}

void Article::getAllWordsFromFile( std::string filepath )
{
    std::ifstream inStream;
    inStream.open(filepath.c_str());
    std::string word;
    
    for (int i = 1 ; inStream >> word ; i++)
        insert(word,i);
}

void Article::expand_table()
{
    int old_size = table_size;
    int old_n= n;

    table_size = nextPrimeAfter(2*table_size);
    h2_param = firstPrimeBefore(table_size);
    
    std::pair<std::string, int>* new_table;
    new_table = new  std::pair<std::string,int> [table_size];

    for(int i = 0 ; i < table_size ; i++)
    {
        std::pair<std::string, int> newPair;
        newPair = std::make_pair(EMPTY_KEY,EMPTY_INDEX);
        new_table[i] = newPair;
    }

    for(int i = 0 ; i < old_size ; i++)
    {
        new_table[i]= table[i];
    }

    delete []table;
    table = new  std::pair<std::string,int> [table_size];

    for(int i = 0 ; i < table_size ; i++)
    {
        std::pair<std::string, int> newPair;
        newPair = std::make_pair(EMPTY_KEY,EMPTY_INDEX);
        table[i] = newPair;
    }

    for(int i = 0 ; i < old_size ; i++)
    {
        if(new_table[i].first != EMPTY_KEY && new_table[i].second != EMPTY_INDEX)
            insert(new_table[i].first,new_table[i].second);
    }
    delete[] new_table;
    n = old_n;
}

int Article::hash_function( std::string& key,int i ) const
{
    int table_index = hash(key,i);
    
    if(table[table_index].first==EMPTY_KEY)
        return table_index;
    else    
        return hash_function(key,i+1);
}


int Article::hash( std::string& key, int i ) const
{
    return (h1(convertStrToInt(key)) + (i * h2(convertStrToInt(key))))%table_size;   
}
    

int Article::h1( int key ) const
{
    unsigned int pop_count = 0;
    
    while (key)
    {
      key &= (key-1) ;
      pop_count++;
    }
    return pop_count*h1_param;
}

int Article::h2( int key ) const
{
    return h2_param-(key % h2_param);
}
