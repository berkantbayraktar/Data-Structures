#include "bookstore.hpp"

BookStore::BookStore( ) //implemented, do not change
{
}

void
BookStore::insert(const Book & book)
{
  SKey *key1 = new SKey(book.getTitle(),book.getAuthor());
  primaryIndex.insert(book.getISBN(),book);

 BSTP::Iterator it = primaryIndex.find(book.getISBN());

 secondaryIndex.insert(*key1,&(*it));
 ternaryIndex.insert(*key1,&(*it));

}

void
BookStore::remove(const std::string & isbn)
{
 // BSTP::Iterator it = primaryIndex.find(isbn);
  //SKey *key1 = new SKey((*it).getTitle(),(*it).getAuthor());
  //primaryIndex.remove(isbn);
  //secondaryIndex.remove(*key1);
 // ternaryIndex.remove(*key1);
 
}

void
BookStore::remove(const std::string & title,
                  const std::string & author)
{
   /* SKey *key = new SKey(title,author);
  BSTS::Iterator it = secondaryIndex.find(*key);
  std::string myIsbn = (*it)->getISBN();
  primaryIndex.remove(myIsbn);*/
}

void
BookStore::removeAllBooksWithTitle(const std::string & title)
{
  /* BSTP::Iterator it;

  for (it=primaryIndex.begin(); it != primaryIndex.end(); ++it)
  {

    std::string title1 = (*it).getTitle();
    std::string title2 = title;

    for(int i=0;title1[i]!='\0';i++){
        if(title1[i]<=122 && title1[i]>=97)
            title1[i]-=32;
      }

      for(int i=0;title2[i]!='\0';i++){
        if(title2[i]<=122 && title2[i]>=97)
            title2[i]-=32;
      }

    if(title1 == title2)
      {
          primaryIndex.remove((*it).getISBN());
      }
  }*/
}

void
BookStore::makeAvailable(const std::string & isbn)
{
   BSTP::Iterator it = primaryIndex.find(isbn);
  (*it).setAvailable();
}

void
BookStore::makeUnavailable(const std::string & title,
                           const std::string & author)
{
    SKey *key = new SKey(title,author);
  BSTS::Iterator it = secondaryIndex.find(*key);
  std::string isbn = (*it)->getISBN();
  BSTP::Iterator it2 = primaryIndex.find(isbn);
  (*it2).setUnavailable();
}

void
BookStore::updatePublisher(const std::string & author, 
                           const std::string & publisher)
{
    BSTP::Iterator it;

  for (it=primaryIndex.begin(); it != primaryIndex.end(); ++it)
  {
    std::string author1 = (*it).getAuthor();
    std::string author2 = author;

    for(int i=0;author1[i]!='\0';i++){
        if(author1[i]<=122 && author1[i]>=97)
            author1[i]-=32;
      }

      for(int i=0;author2[i]!='\0';i++){
        if(author2[i]<=122 && author2[i]>=97)
            author2[i]-=32;
      }


    if(author2 == author1)
      (*it).setPublisher(publisher);
  }
}

void
BookStore::printBooksWithISBN(const std::string & isbn1,
                              const std::string & isbn2,
                              unsigned short since) const
{
   std::list<BSTP::Iterator> myList = primaryIndex.find(isbn1,isbn2);

  while(!myList.empty())
  {
   if((*(myList.front())).getYear() >= since)
   {
      std::cout << *(myList.front());
      std::cout<<std::endl;
      
    }
    myList.pop_front();
    
  }

}

void
BookStore::printBooksOfAuthor(const std::string & author,
                              const std::string & first,
                              const std::string & last) const
{
    BSTS::Iterator it;

  for (it=secondaryIndex.begin(); it != secondaryIndex.end(); ++it)
  {
    std::string author1 = (*(*it)).getAuthor();
    std::string author2 = author;
    std::string title1 = (*(*it)).getTitle();
    std::string title2 = first;
    std::string title3  = last;

    for(int i=0;author1[i]!='\0';i++){
        if(author1[i]<=122 && author1[i]>=97)
            author1[i]-=32;
      }

      for(int i=0;author2[i]!='\0';i++){
        if(author2[i]<=122 && author2[i]>=97)
            author2[i]-=32;
      }

    for(int i=0;title1[i]!='\0';i++){
        if(title1[i]<=122 && title1[i]>=97)
            title1[i]-=32;
      }

      for(int i=0;title2[i]!='\0';i++){
        if(title2[i]<=122 && title2[i]>=97)
            title2[i]-=32;
      }

      for(int i=0;title3[i]!='\0';i++){
        if(title3[i]<=122 && title3[i]>=97)
            title3[i]-=32;
      }


    if(author2 == author1)
      {
          if(title1 >= title2 && title1<= title3)
          std::cout << *(*it) << std::endl;
      }
  }

}

void //implemented, do not change
BookStore::printPrimarySorted( ) const
{
  BSTP::Iterator it;

  for (it=primaryIndex.begin(); it != primaryIndex.end(); ++it)
  {
    std::cout << *it << std::endl;
  }
}

void //implemented, do not change
BookStore::printSecondarySorted( ) const
{
  BSTS::Iterator it;

  for (it = secondaryIndex.begin(); it != secondaryIndex.end(); ++it)
  {
    std::cout << *(*it) << std::endl;
  }
}

void //implemented, do not change
BookStore::printTernarySorted( ) const
{
  BSTT::Iterator it;

  for (it = ternaryIndex.begin(); it != ternaryIndex.end(); ++it)
  {
    std::cout << *(*it) << std::endl;
  }
}

