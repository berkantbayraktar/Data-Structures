#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "Playlist.hpp"
#include "Entry.hpp"

using namespace std;


Playlist::Playlist()
{
    srand(15);
}

int Playlist::getRandomNumber(int i, int n) const
{
    int range=n-i;
    int random = rand() % range + i;
    return random;
}

void Playlist::print()
{
    cout << "[PLAYLIST SIZE=" << entries.getSize() <<"]";
    entries.print();
}
void Playlist::printHistory()
{
    cout<<"[HISTORY]";
    history.print();
}

/* TO-DO: method implementations below */

void Playlist::load(std::string fileName)
{
    ifstream inStream;
    inStream.open(fileName.c_str());

    if (!inStream.good()){
        //cout << endl << "Unable to open the given file" << endl;
        return;
    }

    string title, genre,year;

   // entries.clear();
    while (getline(inStream,title,';')&&getline(inStream,genre,';')&&(getline(inStream,year)||1))
    {
        HistoryRecord hist = HistoryRecord(INSERT,Entry(title,genre,year));

        if(entries.isEmpty()){
            entries.insertNode(NULL,Entry(title,genre,year));
            history.push(hist);
        }
        else{
            entries.insertNode(entries.getTail(),Entry(title,genre,year));
            history.push(hist);
        }
    }      
}


void Playlist::insertEntry(const Entry &e)
{
	HistoryRecord hist = HistoryRecord(INSERT,e);

		if(entries.isEmpty())
		{
        	entries.insertNode(NULL,e);
        	history.push(hist);
    	}
        else{
        	entries.insertNode(entries.getTail(),e);
        	history.push(hist);
        }
}

void Playlist::deleteEntry(const std::string &_title)
{

    Node<Entry> *currentNode = entries.getHead();

    while(!(currentNode->getData().getTitle() == _title))
    {   
     
        currentNode = currentNode->getNext();
    }

    HistoryRecord hist = HistoryRecord(DELETE,currentNode->getData());
    history.push(hist);

    Node<Entry> *prev= entries.findPrev(currentNode->getData());

    if(prev)
        entries.deleteNode(prev);
    else
    {
        entries.setHead(currentNode->getNext());
        entries.deleteNode(entries.getHead());
    }

}

void Playlist::moveLeft(const std::string &title)
{
    Node<Entry> *currentNode = entries.getHead();

    while(!(currentNode->getData().getTitle() == title))
    {   
        
        currentNode = currentNode->getNext();
    }

  
    Node<Entry> *prev= entries.findPrev(currentNode->getData());

    if(currentNode->getData() == entries.getHead()->getData()) // FİRST NODE
    {
        return ;
    }
    else if(currentNode->getData() == entries.getHead()->getNext()->getData()) // SECOND NODE
    {
        entries.setHead(currentNode);
    }

    else if(prev->getNext()->getData() == entries.getTail()->getData()) //LAST
    {
        Node<Entry> *prevv = entries.findPrev(prev->getData());
        prev->setNext(currentNode->getNext());
        prevv->setNext(currentNode);
        currentNode->setNext(prev);
        entries.setTail(prev);
    }

     else //ELSE
    {
        Node<Entry> *prevv = entries.findPrev(prev->getData());
        prev->setNext(currentNode->getNext());
        prevv->setNext(currentNode);
        currentNode->setNext(prev);
    }

}

void Playlist::moveRight(const std::string &title)
{
    Node<Entry> *currentNode = entries.getHead();

    while(!(currentNode->getData().getTitle() == title))
    {          
        currentNode = currentNode->getNext();
    }

  
    Node<Entry> *prev= entries.findPrev(currentNode->getData());
    Node<Entry> *prev_tail = entries.findPrev(entries.getTail()->getData());

    if(currentNode->getData() == entries.getTail()->getData()) // LAST NODE
    {
        return ;
    }
    else if(currentNode->getData() == prev_tail->getData()) //PREV OF LAST
    {
        Node<Entry> *nextNode = entries.getTail();
        prev->setNext(nextNode);
        nextNode->setNext(currentNode);
        currentNode->setNext(NULL);
        entries.setTail(currentNode);

    }

   else if(currentNode->getData().getTitle() == entries.getHead()->getData().getTitle()) //FİRST
    {   
        Node<Entry> *nextNode = currentNode->getNext();
        moveLeft(currentNode->getNext()->getData().getTitle());
    }

     else //ELSE
    {
        Node<Entry> *nextNode = currentNode->getNext();
        currentNode->setNext(nextNode->getNext());
        prev->setNext(nextNode);
        nextNode->setNext(currentNode);
    }
}
	
void Playlist::reverse()
{
  
    int size = entries.getSize();
    Node<Entry> *currentNode = entries.getTail();
    Node<Entry> *head = entries.getHead();

    for(int i = 0 ; i < size-1 ; i ++)
    {
        Node<Entry> *prev = entries.findPrev(currentNode->getData());

        for(int j = 0 ; j+i < size-1 ; j++)
        {
           
            moveLeft(currentNode->getData().getTitle());
        }
        currentNode = prev;
    }

    entries.setTail(head);
    
    HistoryRecord hist = HistoryRecord(REVERSE);
    history.push(hist);

}

void Playlist::sort()
{
    int size = entries.getSize();

    for(int i = 0 ; i < size-1 ; i++)
    {
        Node<Entry> *dummy = entries.getHead();

        for(int j= 0 ; j < size-1 ; j++)
        {
            if(dummy->getNext()->getData().getTitle() < dummy->getData().getTitle())
                moveLeft(dummy->getNext()->getData().getTitle());
            
            else
                dummy = dummy->getNext();
        }
    } 
}

void Playlist::shuffle()
{
    for(int i =0 ; i< entries.getSize();i++)
    {   
        Node<Entry> *currentNode = entries.getHead();
        int random = getRandomNumber(i,entries.getSize());
        
        for(int j=0;j<i;j++)
            currentNode = currentNode->getNext();
        
        Node<Entry> *secNode = currentNode;
        
        for(int m =0; m<random-i;m++)
            secNode=secNode->getNext();
            
        for(int k=0;k < random-i ; k++)
            moveRight(currentNode->getData().getTitle());
            
        for(int n=0;n<random-i-1;n++)
            moveLeft(secNode->getData().getTitle());
    }
}

void Playlist::merge(const Playlist & pl)
{
    Node<Entry> *currentNode = pl.entries.getHead();
    while(currentNode)
    {   
        size_t index = 0;
        size_t entry_size = 0;
        Node<Entry> *traverse = entries.getHead();
        
        while(traverse)
        {
            if(traverse->getData().getTitle() < currentNode->getData().getTitle())
            {
                index++;
                traverse = traverse->getNext();
            }
            else
                break;
        }

        insertEntry(currentNode->getData());
        history.pop();
        Node<Entry> *prev= entries.findPrev(currentNode->getData());
        entry_size = entries.getSize();
        for(int i = 0 ; i < entry_size-index-1 ; i++)
            moveLeft(currentNode->getData().getTitle());
        
        if  (entry_size-index-1)
            entries.setTail(prev);
        else
            entries.setTail(prev->getNext());

        currentNode = currentNode->getNext();
    }
}



void Playlist::undo()
{
    Node<HistoryRecord> *top = history.Top();

    Operation oper = top->getData().getOperation();
    Entry entry = top->getData().getEntry();

    if(oper == INSERT)
    {
        deleteEntry(entry.getTitle());
        history.pop();
    }

    else if(oper == DELETE)
    {
        insertEntry(entry);
        history.pop();
    }

    else if(oper == REVERSE)
    {
        reverse();
        history.pop();
    }

    history.pop();
}