#ifndef _LINKEDLIST_H_
#define _LINKEDLIST_H_

#include <iostream>
#include "Node.hpp"

using namespace std;

/*....DO NOT EDIT BELOW....*/
template <class T> 
class LinkedList {
    private:
		/*First node of the linked-list*/
        Node<T>* head;
        /*Last node of the linked-list*/
		Node<T>* tail;
		/*size of the linked-list*/
		size_t  size; 
    public:

        LinkedList();
        LinkedList(const LinkedList<T>& ll);
        LinkedList<T>& operator=(const LinkedList<T>& ll);
        ~LinkedList();

        /* Return head of the linked-list*/
        Node<T>* getHead() const;
        /* Set head of the linked-list*/
        void setHead(Node<T>* n);
        /* Return tail of the linked-list*/
        Node<T>* getTail() const;
        /* Set tail of the linked-list*/
        void setTail(Node<T>* n);
        /* Get the previous node of the node that contains the data item. 
         * If the head node contains the data item, this method returns NULL.*/
        Node<T>* findPrev(const T& data) const;
        /* Get the node that stores the data item. 
         * If data is not found in the list, this function returns NULL.*/
        Node<T>* findNode(const T& data) const;
        /* Insert a new node to store the data item. 
         * The new node should be placed after the “prev” node. 
         * If prev is NULL then insert new node to the head.*/
        void insertNode(Node<T>* prev, const T& data); 
        /* This method is used to delete the node that is next to “prevNode”. 
         * PS:prevNode is not the node to be deleted. 
		 * If prev is NULL then delete head node. 
		 */
        void deleteNode(Node<T>* prevNode);  
        /* This method is used to clear the contents of the list.*/
        void clear();
        /* This method returns true if the list empty, otherwise returns false.*/
        bool isEmpty() const;
        /* This method returns the current size of the list. */
        size_t getSize() const;
        /*Prints the list. This method was already implemented. Do not modify.*/
        void print() const;
};

template <class T>
void LinkedList<T>::print() const{
    const Node<T>* node = head;
    while (node) {
        std::cout << node->getData();
        node = node->getNext();
    }
    cout<<std::endl;
}

/*....DO NOT EDIT ABOVE....*/

/* TO-DO: method implementations below */

template <class T>
LinkedList<T>::LinkedList()
{
    size = 0;
    head = NULL;
    tail = NULL;
}
template <class T>
LinkedList<T>::LinkedList(const LinkedList<T>& ll)
{
    size = 0;
    head = NULL;
    tail = NULL;

    *this = ll;
}
template <class T>
LinkedList<T>& LinkedList<T>::operator=(const LinkedList<T>& ll)
{
   if(this == &ll)
    {
        return *this;
    }

    Node <T> *currentNode = ll.getHead();
    Node <T> *here = new Node<T>;	

    while(currentNode)
    {
    	
 		if(head)
 		{
 			Node<T> *newNode = new Node<T>(currentNode->getData());
	        if(!head->getNext())
	        {
	        	head ->setNext(newNode);      	
	        	here = head->getNext();
	        }
	        else
	        {
	      
	        	here->setNext(newNode);  	
	        	here = here->getNext();
	        }
	        currentNode = currentNode->getNext();
    	}
	
    	
    	else
    	{	
        Node<T> *newNode = new Node<T>(currentNode->getData());
        head = newNode;
        currentNode = currentNode->getNext();
    	}

    }
	

    return *this;




}

template <class T>
LinkedList<T>::~LinkedList()
{
    clear();
    delete head;
    delete tail;
}


/* Return head of the linked-list*/
template <class T>
Node<T>* LinkedList<T>::getHead() const
{
    return head;
}

template <class T>
void LinkedList<T>::setHead(Node<T>* n)
{

    if(n == head)
    {
        return ;
    }
    else
    {
        Node<T>*prev = findPrev(n->getData());
        Node<T>*newNode = new Node<T>(n->getData());
        deleteNode(prev);
        size++;
        
        if(prev->getNext() == getTail())
        {
        tail = prev;
        newNode->setNext(head);
        head = newNode;
        }

        else
        {
        newNode->setNext(head);
        head = newNode;
        }
    }
}


/* Return tail of the linked-list*/
template <class T>
Node<T>* LinkedList<T>::getTail() const
{
    return tail;
}

template <class T>
void LinkedList<T>::setTail(Node<T>* n)
{
    tail = n;
}

/* Get the previous node of the node that contains the data item. 
 * If the head node contains the data item, this method returns NULL.*/
template <class T>
Node<T>* LinkedList<T>::findPrev(const T& data) const
{   
    Node<T> *currentNode = head;

    if(head->getData() == data)
    {
        return NULL;
    }

    while(!(currentNode->getNext()->getData() == data))
    {
        currentNode = currentNode->getNext();
    }

    return currentNode;
}

/* Get the node that stores the data item. 
 * If data is not found in the list, this function returns NULL.*/
template <class T>
Node<T>* LinkedList<T>::findNode(const T& data) const
{   
    Node<T> * currentNode = head;

    while(!(currentNode->getData() == data))
    {
        currentNode = currentNode->getNext();
    }

    return currentNode;
}

/* Insert a new node to store the data item. 
 * The new node should be placed after the “prev” node. 
 * If prev is NULL then insert new node to the head.*/
template <class T>
void LinkedList<T>::insertNode(Node<T>* prev, const T& data)
{
    Node<T> *newNode = new Node<T>(data);
    newNode->setNext(NULL);

    if(prev != NULL)
    {
        newNode->setNext(prev->getNext());
        prev->setNext(newNode);
        tail = newNode;
    }

    else
    {   
        head = new Node<T>;
        tail = new Node<T>;
        head = newNode;
        tail = newNode;
        head->setNext(NULL);
        tail->setNext(NULL);
    }

    size++;
    
    
}

/* This method is used to delete the node that is next to “prevNode”. 
 * PS:prevNode is not the node to be deleted. */
template <class T>
void LinkedList<T>::deleteNode(Node<T>* prevNode)
{
    
    if(prevNode == findPrev(getTail()->getData()))
    {
        Node<T> *deletedNode = new Node<T>;
        deletedNode = prevNode->getNext();
        prevNode->setNext(NULL);
        tail = prevNode;
        delete deletedNode;
    }

    else if(prevNode)
    {
        Node<T> *deletedNode = new Node<T>;
        deletedNode = prevNode->getNext();
        prevNode->setNext(deletedNode->getNext());
        delete deletedNode;
    }
    size--;
}  

/* This method is used to clear the contents of the list.*/
template <class T>
void LinkedList<T>::clear()
{
   while(head->getNext() != NULL)
    {
    deleteNode(head);
    }
    head = NULL;
    tail = NULL;

    
}

/* This method returns true if the list empty, otherwise returns false.*/
template <class T>
bool LinkedList<T>::isEmpty() const
{
        return !getSize();
}
        
/* This method returns the current size of the list. */
template <class T>
size_t LinkedList<T>::getSize() const
{
        return size;
}


/* end of your implementations*/

#endif
