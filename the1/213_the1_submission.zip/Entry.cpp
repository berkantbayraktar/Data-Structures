#include <cstdlib>
#include <iostream>
#include <string>
#include "Entry.hpp"

using namespace std;

std::ostream &operator<<(std::ostream &out, const Entry& t){
    out <<"{"<< t.title<<","<<t.genre<<","<<t.year<<"}";
    return out;
};

Entry :: Entry()
{

}


std::string Entry::getTitle() const
{
	return title;
}

std::string Entry::getGenre() const
{
	return genre;
}

std::string Entry::getYear() const
{	
	return year;
}

bool Entry::operator==(const Entry & rhs) const
{
	return getTitle() == rhs.getTitle();
}

/* TO-DO: method implementations below */

